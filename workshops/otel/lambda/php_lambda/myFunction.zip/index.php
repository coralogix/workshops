<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use OpenTelemetry\SDK\Trace\TracerProviderFactory;
use OpenTelemetry\Contrib\Otlp\OtlpHttpTransportFactory;
use OpenTelemetry\SDK\Trace\SpanProcessor\BatchSpanProcessor;
use OpenTelemetry\SDK\Trace\SpanExporter\SpanExporterFactoryInterface;
use OpenTelemetry\Contrib\Otlp\SpanExporter;
use OpenTelemetry\SDK\Trace\TracerProvider;
use OpenTelemetry\SDK\Trace\SpanProcessor\SimpleSpanProcessor;

require __DIR__ . '/vendor/autoload.php';

// Step 2: Check if the required PHP extension 'ctype' is loaded.
if (!extension_loaded('ctype')) {
    error_log("ERROR: ctype PHP extension is NOT loaded. Exiting...");
    exit(255); // Exit with error code 255
}
error_log("INFO: ctype PHP extension is loaded.");

// Step 3: Create a Slim application instance for routing and request handling.
try {
    $app = AppFactory::create();
    error_log("INFO: Slim application instance created successfully.");
} catch (Throwable $e) {
    error_log("ERROR: Failed to create Slim application instance - " . $e->getMessage());
    exit(255); // Exit with error code 255
}

// Step 4: Define the /test-tracer route.
$app->get('/test-tracer', function (Request $request, Response $response) {
    error_log("INFO: /test-tracer route invoked.");

    try {
        // Step 4.1: Retrieve OTLP endpoint from the environment variable
        $otlpEndpoint = getenv('OTEL_EXPORTER_OTLP_TRACES_ENDPOINT');
        if (!$otlpEndpoint) {
            error_log("ERROR: OTEL_EXPORTER_OTLP_TRACES_ENDPOINT environment variable is not set.");
            return $response->withStatus(500)->write(json_encode(['error' => 'OTLP endpoint not configured.']));
        }
        error_log("INFO: OTLP endpoint: $otlpEndpoint");

        // Step 4.2: Initialize OTLP HTTP Transport
        error_log("INFO: Initializing OTLP HTTP Transport...");
        $transport = (new OtlpHttpTransportFactory())->create($otlpEndpoint, 'application/x-protobuf');
        error_log("INFO: OTLP HTTP Transport initialized successfully.");

        // Step 4.3: Initialize OTLP Span Exporter
        error_log("INFO: Initializing OTLP Span Exporter...");
        $exporter = new SpanExporter($transport);
        error_log("INFO: OTLP Span Exporter initialized successfully.");

        // Step 4.5: Initialize TracerProvider
        error_log("INFO: Initializing TracerProvider...");
        $tracerProvider = new TracerProvider(
            new SimpleSpanProcessor(
                $exporter
            )
        );
        error_log("INFO: TracerProvider initialized successfully.");

        // Step 4.6: Retrieve a Tracer instance
        error_log("INFO: Retrieving Tracer instance...");
        $tracer = $tracerProvider->getTracer('io.opentelemetry.contrib.php');
        error_log("INFO: Tracer instance retrieved successfully.");

        // Step 4.7: Start a new span
        error_log("INFO: Starting new span...");
        $spanBuilder = $tracer->spanBuilder('test-span')->setSpanKind(\OpenTelemetry\API\Trace\SpanKind::KIND_INTERNAL);
        $span = $spanBuilder->startSpan();
        error_log("INFO: Span started with kind INTERNAL.");

        // Add attributes to the span
        error_log("INFO: Adding attributes to the span...");
        $attributesArray = [
            'example.attribute' => 'test-value'
        ];
        $span->setAttribute('example.attribute', 'test-value');
        error_log("INFO: Attribute 'example.attribute' set to 'test-value'.");

        // Retrieve additional resource attributes from environment variables
        error_log("INFO: Retrieving resource attributes from environment variables...");
        $resourceAttributes = getenv('OTEL_RESOURCE_ATTRIBUTES');
        if ($resourceAttributes) {
            foreach (explode(',', $resourceAttributes) as $attribute) {
                [$key, $value] = explode('=', $attribute, 2);
                $attributesArray[$key] = $value;
                $span->setAttribute($key, $value);
                error_log("INFO: Attribute '$key' set to '$value'.");
            }
        }

        // Explicitly add service.name from environment variables
        $serviceName = getenv('OTEL_SERVICE_NAME');
        if ($serviceName) {
            $attributesArray['service.name'] = $serviceName;
            $span->setAttribute('service.name', $serviceName);
            error_log("INFO: Attribute 'service.name' set to '$serviceName'.");
        }

        // Log span details in JSON before exporting
        error_log("INFO: Logging span details in JSON...");
        $startTime = microtime(true); // Record start time
        $spanData = [
            'traceId' => $span->getContext()->getTraceId(),
            'spanId' => $span->getContext()->getSpanId(),
            'name' => 'test-span',
            'kind' => 'INTERNAL',
            'startTime' => $startTime, // Approximate start time
            'attributes' => $attributesArray,
            'resource' => [
                'service.name' => $serviceName,
                'cx.domain' => getenv('CX_DOMAIN'),
                'cx.reporting.strategy' => getenv('CX_REPORTING_STRATEGY')
            ]
        ];
        $endTime = microtime(true); // Record end time
        $spanData['endTime'] = $endTime; // Approximate end time
        error_log(json_encode($spanData));

        // End the span
        error_log("INFO: Ending the span...");
        $span->end();
        error_log("INFO: Span ended successfully.");

        // Step 4.8: Shutdown TracerProvider
        error_log("INFO: Shutting down TracerProvider...");
        $tracerProvider->shutdown();
        error_log("INFO: TracerProvider shut down successfully. Spans exported.");
    } catch (Throwable $e) {
        error_log("ERROR: Exception occurred during tracing - " . $e->getMessage());
        error_log("ERROR: Stack trace - " . $e->getTraceAsString());
        return $response->withStatus(500)->write(json_encode(['error' => 'Tracing failed.']));
    }

    // Step 4.10: Return success response
    error_log("INFO: /test-tracer completed successfully.");
    $response->getBody()->write(json_encode(['status' => 'Tracer tested and spans exported']));
    return $response->withHeader('Content-Type', 'application/json');
});

// Step 5: Return the Slim application instance for AWS Lambda to invoke.
error_log("INFO: Returning Slim application instance for AWS Lambda.");
return $app;
